Name: Saljooq Altaf
Net ID: saltaf


Assignment 1.07


Same program as 1.06 but with eight new methods as shown below:
int print_monster_desc();
int parseMonstersDesc();
string getColorString(int i);
string intToAbil(int abil);
string getColorString(int i);
int finddice(int* ar, string s);
int getColorint(string t);
int get_abilities(string abil);
And one new class of monster description.
